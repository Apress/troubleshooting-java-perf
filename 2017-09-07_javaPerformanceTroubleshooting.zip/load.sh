mvn -f pom-load.xml -Djmeter.test=$1.jmx

