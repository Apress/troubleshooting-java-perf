package com.github.eostermueller.perfSandbox;

public interface Logger {
	void log(String v);
}
