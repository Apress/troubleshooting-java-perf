package com.github.eostermueller.perfSandbox.parse;

public enum CountType {
	HR7983, //between 1979 and 1983
	HR8587, //between 1985 and 1987 
	HR8995,  //between 1989 and 1995
	OTHER


}
