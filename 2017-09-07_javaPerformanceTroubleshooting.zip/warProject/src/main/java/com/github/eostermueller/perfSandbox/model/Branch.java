package com.github.eostermueller.perfSandbox.model;

import com.github.eostermueller.perfSandbox.dataaccess.PerfSandboxUtil;

public class Branch {
	public int bid = PerfSandboxUtil.UN_INIT;
	public long bbalance = PerfSandboxUtil.UN_INIT;
	public String filler = null;
}
