package com.github.eostermueller.perfSandbox.dataaccess;


public class BaseManager {
	
}
