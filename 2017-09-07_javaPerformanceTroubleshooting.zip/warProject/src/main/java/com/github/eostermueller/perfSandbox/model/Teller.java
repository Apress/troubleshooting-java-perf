package com.github.eostermueller.perfSandbox.model;

public class Teller {

}
