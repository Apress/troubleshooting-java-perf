mvn clean deploy
