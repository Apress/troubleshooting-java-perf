mvn verify -Pno-gui -DtestEnvironment=stage -f pom-load.xml 

