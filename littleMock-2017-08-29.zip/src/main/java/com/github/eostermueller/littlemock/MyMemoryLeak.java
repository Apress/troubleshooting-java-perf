package com.github.eostermueller.littlemock;

public class MyMemoryLeak {
	byte b = 'j';
}
