package com.github.eostermueller.littlemock;

public interface IntegerChangeListener {
	void newValue(int val);
}
