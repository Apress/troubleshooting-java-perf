package com.github.eostermueller.littlemock.xslt;

public class XsltFile extends XmlFile {

	public XsltFile(String fullName) {
		super(fullName);
	}


}
